**To delete a placement group**

This example command deletes the specified placement group.

Command::

  aws ec2 delete-placement-group --group-name my-cluster
